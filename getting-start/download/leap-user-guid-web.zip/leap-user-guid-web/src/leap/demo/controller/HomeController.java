package leap.demo.controller;

public class HomeController {
	public void index() {
		
	}
}
